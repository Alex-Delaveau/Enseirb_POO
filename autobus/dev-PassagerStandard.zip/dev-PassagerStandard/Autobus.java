//source without documentation for javadoc

class Autobus {

  // constructor
  public Autobus(int nbPlaceAssise, int nbPlaceDebout) {
  }

  //methods
  public boolean aPlaceAssise() {
    return false;
  }

  public boolean aPlaceDebout() {
    return false;
  }

  public void monteeDemanderAssis(PassagerStandard p) {
  }

  public void monteeDemanderDebout(PassagerStandard p) {
  }

  public void allerArretSuivant() {
  }

  public void arretDemanderAssis(PassagerStandard p) {
  }

  public void arretDemanderDebout(PassagerStandard p) {
  }

  public void arretDemanderSortie(PassagerStandard p) {
  }
}
